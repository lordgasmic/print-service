Star_JavaPOS_Driver_linux
Ver 1.13.16
---------------------------------------

このファイルでは、マニュアル(starjavapos_sm_jp.pdf)に記載されていない
事項について補足させて頂きます。


ファイルおよびフォルダ構成：
    . starjavapos.jar
    . stario.jar
    . commandemulator.jar
    . jpos113-controls.jar
    . jcl.jar
    . xercesimpl.jar
    . xml-apis.jar
    . jpos.xml
    . StarReceiptTest.java
    . StarSlipTest.java
    . StarCashDrawerTest.java
    . StarMICRTest.java
    . star.gif
    . StarIOPort_Install_x32(x64)
    . SoftwareLicenseAgreement.pdf
    . SoftwareLicenseAgreement_jp.pdf
    . SoftwareLicenseAgreementAppendix.pdf
    . readme_en.txt
    . readme_jp.txt
    . 49-starusbprn.rules
    . DiscoveryTool


評価環境：
    次のディストリビューションで評価を行っています。
        Red Hat Enterprise Linux 9.5 (64bit)
        Ubuntu 16.04LTS (32bit) / 24.04 LTS (64bit)

    ※ TSP100シリーズをご利用の場合、「Xerces-C++ バージョン 2.7.0」
       が必要になります。「Xerces-C++ バージョン 2.7.0」を
       インストールしてからご使用ください。


Java実行環境：
    Java Standard Edition 8以降


前準備 - StarIOPortのインストール
    StarJavaPOSパッケージにある"StarIOPort_Install_x32(x64)"フォルダを開いて、 "install.sh"のスクリプトを実行してください。
    ターミナルを開き、ルート権限で次のコマンド"/bin/bash install.sh"を実行してください。 
    "/usr/lib(64)"フォルダにライブラリを、"/usr/include"フォルダにヘッダーファイルをコピーします。
    
    例） Ubuntu x64
    [j2@localhost starjavapos_1.13.nn_linux_64bit_yyyymmdd]$ cd StarIOPort_Install_x64/
    [j2@localhost StarIOPort_Install_x11]$ sudo /bin/bash install.sh
    Complete!


コンフィグレーションサンプル - jpos.xml：
    Star JavaPOSドライバは、デバイスコントロールとStar JavaPOS
    デバイスサービスを接続するために、JCL(JavaPOS Configuration /
    Loader)を使用します。jpos.xmlファイルには、Star POSプリンタと
    接続するためのサンプルが記述されています。

    以下は、POSPrinterエントリの設定例リストです。
        . POSPrinter_linux_parallel
        . POSPrinter_linux_serial
        . POSPrinter_linux_usb_printer_class
        . POSPrinter_linux_usb_vendor_class
        . POSPrinter_linux_ethernet
        . POSPrinter_linux_bluetooth

    以下は、CashDrawerエントリの設定例リストです。
        . CashDrawer_linux_parallel
        . CashDrawer_linux_serial
        . CashDrawer_linux_usb_printer_class
        . CashDrawer_linux_usb_vendor_class
        . CashDrawer_linux_ethernet
        . CashDrawer_linux_bluetooth

    以下はPOSPrinterの追加プロパティです。
        . useNVLogoImage
        記述例：    <prop name="useNVBitImage" type="Boolean" value="true" />
    ※ useNVLogoImageプロパティをtrueに設定することで、エスケープシーケンス"ESC | # B (#は数字)"にてNVロゴ印刷が出来ます。


    設定の詳細は、starjavapos_sm_jp.pdfをご参照ください。


使用例：
    StarReceiptTest.java、StarCashDrawerTest.javaをご参照ください。


制限事項と注意事項
    Bluetoothプリンターを利用時、印字中にプリンターの電源が切れた際、復帰後の印字が行えない場合があります。
    その場合は、プリンターの電源を再度入れ直すか、PCでBluetoothを一旦オフ、再度オンにすることで復帰できます。
    1回で復旧しない場合は繰り返し実施してください。
    

リリース履歴

2006/12/27 "portName"と"portSettings"を下記ドライバから変更。
Ver 1.9.6  starjavapos_win32-linux-macosx_20051101.zip

2007/03/17 機種追加：TSP700II
Ver 1.9.7

2007/07/17 機種追加：TSP650
Ver 1.9.8

2008/12/12 機種追加：TUP500
Ver 1.9.13

2010/12/28 機種追加：FVP10、TSP800II。
Ver 1.13.0 JavaPOS Ver. 1.13.0準拠。

2011/04/18 2バイト文字に対応。Linux 64bit対応。
Ver 1.13.1

2011/05/31 Bug-fix release
Ver 1.13.2 全機種：Textのみの倒立印字ができない不具合の修正
           TSP100シリーズ：1行未満のデータを送信するとエラーが出力される不具合の修正

2012/06/29 Bug-fix release
Ver 1.13.3 全機種:非同期実行時、clearOutput()でエラーが出力される不具合の修正
                  clearoutPut()実行時、倒立印字及びトランザクション印字が解除されない不具合の修正
                  エスケープシーケンスによるロゴ印刷でrotatePrint()が反映されない不具合の修正
                  setLogo()にエスケープシーケンスによるトップ及びボトムロゴ印刷を含めたとき印字する不具合の修正
                  バーコード印字において、印字領域を超えるAlignmentの指定ができる不具合の修正
                  エスケープシーケンスによるＮＶロゴ印字の機能追加
           TSP100シリーズ：印字領域幅指定(printableArea)で58mm指定出来ない不具合の修正

2012/11/22 機種追加：TSP650II、I/F追加：Bluetooth
Ver 1.13.4

2013/10/30 stario.jar パッケージ構成変更
           libStarIOJ.soをインストールするようにinstall.shを修正
Ver 1.13.5

2013/11/27 機種追加：SAC10EBi、SAC10E (キャッシュドロワーインターフェイスBOX)
Ver 1.13.6 SAC10EのIPアドレスを検索するためのDiscoveryToolを追加
           Bluetooth I/Fにおいて印字中に電源をOffにした後、再度電源を
           onにしても正常復帰しない不具合の修正

2014/06/09 Bluetooth対応機種追加:TSP700II, TSP800II
Ver 1.13.7

2015/01/26 Bluetooth対応機種追加:FVP10
Ver 1.13.8

2015/12/17 TSP100IIIW, TSP100IIILAN 対応(32bit版OSのみ)
Ver 1.13.9

2016/06/27 TSP100IIIBI 対応(32bit版OSのみ)
Ver1.13.10 2次元バーコード対応
            - PDF417, QR code
           デフォルトコードページ変更プロパティを追加

2019/04/09 バグ修正:複数のCashDrawerデバイスを同時に正しく制御できない問題を修正
Ver1.13.11

12/25/2019 Linux 64bitでTSP100シリーズに対応
ver1.13.12 機能追加:jpos.xmlにimageBinarizationThresholdプロパティを追加
                    画像の印字速度を改善 (printBitmap, setBitmap)
           バグ修正:一台のプリンターの複数デバイスクラス(POSPrinter, Drawer)に対し、
                    deviceEnabledプロパティを同時にtrueに設定できない問題を修正
           サポート終了機種:TSP113, TSP113GT, TSP113LAN, SAC10

2022/01/18 機能追加:(POSPrinter)エスケープシーケンス カスタムカラーに対応 (SP700のみ)
Ver1.13.13 サポート終了機種:TSP650, FVP10

2023/03/31 ドライバーパッケージ統合
Ver1.13.14 機種追加：mC-Label3

2024/06/24 Java実行環境 : Java Standard Edition 8以降に変更
Ver1.13.15 

2025/05/19 機種追加:mC-Label2（300dpiモデル）
Ver1.13.16 機能追加:markFeedメソッドに対応（mC-Label2とmC-Label3）
                    基本印字サイズを設定するためのbaseTextMagnificationプロパティをjpos.xmlに追加