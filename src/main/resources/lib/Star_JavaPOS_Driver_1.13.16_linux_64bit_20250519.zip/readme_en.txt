Star_JavaPOS_Driver_linux
Ver 1.13.16
---------------------------------------


Package Contents:
    . starjavapos.jar
    . stario.jar
    . commandemulator.jar
    . jpos113-controls.jar
    . jcl.jar
    . xercesimpl.jar
    . xml-apis.jar
    . jpos.xml
    . StarReceiptTest.java
    . StarSlipTest.java
    . StarCashDrawerTest.java
    . StarMICRTest.java
    . star.gif
    . StarIOPort_Install_x32(x64)
    . SoftwareLicenseAgreement.pdf
    . SoftwareLicenseAgreement_jp.pdf
    . SoftwareLicenseAgreementAppendix.pdf
    . readme_en.txt
    . readme_jp.txt
    . 49-starusbprn.rules
    . DiscoveryTool


Supported Operating Systems:
    The evaluation environment is as follows:
        Red Hat Enterprise Linux 9.5 (64bit)
        Ubuntu 16.04LTS (32bit) / 24.04 LTS (64bit)

    * TSP100U/PU or TSP100GT or TSP100LAN or TSP100IIU
    If you use the above models, you need Xerces-C++ Version 2.7.0 on
    your linux system.  Please download Xerces-C++ Version 2.7.0
    from the package archive homepage of each linux system.


Java Virtual Machine Requirement:
    Java Standard Edition 8 or later


Preparation - Installing StarIOPort
    Browse to the StarJavaPOS directory "StarIOPort_Install_x32(x64)" and run the bash script named
    "install.sh". To run it, login as root and issue this command in the terminal "/bin/bash install.sh" 
    once you change to this  directory. This will copy the library file to the "/usr/lib(64)" directory and
    header file to the "/usr/include" directory.
    
    e.g) Ubuntu x64
    [j2@localhost starjavapos_1.13.nn_linux_64bit_yyyymmdd]$ cd StarIOPort_Install_x64/
    [j2@localhost StarIOPort_Install_x64]$ sudo /bin/bash install.sh
    Complete!


Configuration Sample - jpos.xml:
    StarJavaPOS uses the JCL - Java Configuration Loader system for
    configuring the provided services.  The file jpos.xml contained
    in this package has been initialized with device entries for
    Star's newest printer products.

    The following is a list of the POSPrinter device entries
    contained in this file as indexed by their logicalName field:
        . POSPrinter_linux_parallel
        . POSPrinter_linux_serial
        . POSPrinter_linux_usb_printer_class
        . POSPrinter_linux_usb_vendor_class
        . POSPrinter_linux_ethernet
        . POSPrinter_linux_bluetooth

    The following is a list of the DotMatrixPrinter device entries
    contained in this file as indexed by their logicalName field:
        . DotMatrixPrinter_linux_bluetooth
    NOTE: The DotMatrix of the jpos.xml settings is 
          same as the POSPrinter device entries.

    The following is a list of the CashDrawer device entries
    contained in this file as indexed by their logicalName field:
        . CashDrawer_linux_parallel
        . CashDrawer_linux_serial
        . CashDrawer_linux_usb_printer_class
        . CashDrawer_linux_usb_vendor_class
        . CashDrawer_linux_ethernet
        . CashDrawer_linux_bluetooth

    The following is a list of the MICR device entries
    contained in this file as indexed by their logicalName field:
        . HSP7000_MICR_linux_parallel
        . HSP7000_MICR_linux_serial
        . HSP7000_MICR_linux_usb_vendor_class
        . HSP7000_MICR_linux_ethernet
    NOTE: The HSP7000's MICR function is not supported in USB
          Printer Class Mode.

    The following is an adding property of POSPrinter
        . useNVBitImage
        example:  <prop name="useNVBitImage" type="Boolean" value="true" />
    NOTE: If "useNVLogoImage property" set the "true", can use "NV Logo Print" by escape sequence(ESC | # B). 

    Please refer to starjavapos_sm_en.pdf for details.


Usage - Test Application:
    Open StarReceiptTest.java, StarSlipTest.java,
    StarCashDrawerTest.java and StarMICRTest.java.
    Then, refer to the usage instructions.


Restrictions and Cautions
    When using a Bluetooth printer, printing may not be possible after recovery if the printer's power is turned off during printing.
    In that case, it is possible to recover by turning the printer off and then on again, or turning Bluetooth off and on again on your PC.
    If it doesn't recover at one time, please retry it.


Release History

12/27/2006 Changed portSettings field value of serial port from
Ver 1.9.6  starjavapos_win32-linux-macosx_20051101.zip

           Changed portName field value from
           starjavapos_win32-linux-macosx_20051101.zip

03/17/2007 Added TSP700II
Ver 1.9.7

07/17/2007 Added TSP651/654
Ver 1.9.8

12/25/2007 Added TSP100GT
Ver 1.9.9

03/24/2008 Added TSP100LAN
Ver 1.9.10

04/25/2008 Added HSP7000
Ver 1.9.12

03/11/2009 Added TUP500
Ver 1.9.13

03/01/2010 Added TSP100IIU, supported CheckHealth(JPOS_CH_INTERACTIVE)
Ver 1.9.14

06/16/2010 Modified CashDrawer, StarReceiptTest.java, StarCashDrawerTest.java
Ver 1.9.15

12/28/2010 Added FVP10, TSP800II, SP500,
Ver 1.13.0 JavaPOS Ver. 1.13.0

04/18/2011 Support DBCS, Linux 64bit
Ver 1.13.1

05/31/2011 Bug-fix release
Ver 1.13.2 All models:
            Debug 180 degree rotation command
            When set 180 rotation, cannot set rotation if data is only text.
           TSP100 series:
            Debug error output bug
            When JavaPOS driver receives less than one line data,
            JavaPOS driver output "NullPointerException".

06/29/2012 Bug-fix release
Ver 1.13.3 All models:
            Debug following clearOutput() issues. 
                When set asyncMode, cannot perform clearOutput(). JavaPOS driver output "JPOS_E_FAILER"
                When perform clearOutput(), cannot release tranzactionPrint() and rotatePrint().
            Debug following setLogo issue
                When perform setLogo(), can set top or bottom logo by escape sequence.
            Debug following barcode print issue
                can set alignment which is over printableArea.
            Added a function of "NV Logo Print" by escape sequence.
           TSP100 series:
            Debug specify printableArea
                cannot set printableArea value of 58mm.

11/22/2012 Added TSP650II, Bluetooth I/F
Ver 1.13.4

10/30/2013 Modified the configuration of package in stario.jar.
           Modified install.sh to install "libStarIOJ.so".
Ver 1.13.5

11/27/2013 Added SAC10EBi, SAC10E (CashDrawer Interface BOX)
Ver 1.13.6 Added DiscoveryTool to get the IP Address of SAC10E
           Modified issue about the Bluetooth I/F which is not to return normally status,
           even if turn on a power supply again after turning off power supply during printing.

06/09/2014 Added models support Bluetooth interface newly.
Ver 1.13.7 TSP700II, TSP800II, SP700(only SP742).   

01/26/2015 Added models support Bluetooth interface newly.
Ver 1.13.8 FVP10.

12/17/2015 Added models support newly.
Ver 1.13.9 TSP100IIIW, TSP100IIILAN(32bit OS only)

06/27/2016 Added a model support newly.
Ver 1.13.10  - TSP100IIIBI (32bit OS only)
            Added support 2-dimensional bar code
             - PDF417, QR code
            Added property to change the default codepage (jpos.xml)

04/09/2019 Bug Fix:cannot control multiple CashDrawer devices simultaneously.
ver1.13.11

12/25/2019 Support TSP100 Series on Linux 64bit.
ver1.13.12 New function: Added imageBinarizationThreshold property to jpos.xml.
                         Improved printing speed (printBitmap, setBitmap).
           Bug Fix: cannot set the 'deviceEnabled' properties of one printer's device class(POSPrinter, Drawer) 
                    to 'true' simultaneously.
           End Support: TSP113, TSP113GT, TSP113LAN, SAC10

01/18/2022 New function: (POSPrinter) Added support "Alternate color (Custom)" escape sequence (only SP700).
ver1.13.13 End Support: TSP650, FVP10, SP500

03/31/2023 Integrated JavaPOS Driver package.
Ver1.13.14 Added mC-Label3

06/24/2024 Java Virtual Machine Requirement: Changed to Java Standard Edition 8 or later
Ver1.13.15 Added BSC10II

05/19/2025 Added mC-Label2
Ver1.13.16 New function: Supported the markFeed method (mC-Label2 and mC-Label3).
                         Added baseTextMagnification property to jpos.xml to set base print size.